
#include "stm32f4xx.h"
#include "delay.h"
#include "led.h"

int main()
{
	Systick_Init();
	LED_Init();
	LED0 = LED1 = LED2 = LED3 = 1;
	while(1)
	{
//		LED0 = !LED0;
//		delay_ms(100);
//		LED1 = !LED1;
//		delay_ms(100);
//		LED2 = !LED2;
//		delay_ms(100);
//		LED3 = !LED3;
//		delay_ms(100);
	}
}
