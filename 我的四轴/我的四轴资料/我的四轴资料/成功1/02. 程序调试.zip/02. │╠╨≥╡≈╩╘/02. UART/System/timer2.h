#ifndef __TIMER2_H
#define __TIMER2_H

#include "stm32f4xx.h"

void TIM2_Init(void);

#endif
