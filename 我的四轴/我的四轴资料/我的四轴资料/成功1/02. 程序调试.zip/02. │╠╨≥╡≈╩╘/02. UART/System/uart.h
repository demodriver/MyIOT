#ifndef __UART_H
#define __UART_H

#include "stm32f4xx.h"

void USART2_Init(void);
void USART2_Send1Byte(u8 byte);
void USART2_SendNByte(u8 *data, u16 num);
void USART2_SendString(u8 *str);

#endif

