
#include "stm32f4xx.h"
#include "delay.h"
#include "led.h"
#include "uart.h"

int main()
{
	Systick_Init();
	USART2_Init();
	LED_Init();
	while(1)
	{
		LED0 = !LED0;
		delay_ms(500);
	}
}
