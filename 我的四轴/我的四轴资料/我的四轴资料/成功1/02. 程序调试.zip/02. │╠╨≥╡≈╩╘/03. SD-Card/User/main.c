
#include "stm32f4xx.h"
#include "sdio_sd.h"
#include "diskio.h"
#include "delay.h"
#include "stdio.h"
#include "led.h"
#include "ff.h"

FATFS SD_fs;            // �߼����̹�����.	  
FIL SD_file;	          // �ļ�1
FRESULT SD_res;         // ���ؽ��        
DIR SD_dirs;            // Ŀ¼
FILINFO SD_fileinfo;    // �ļ���Ϣ

uint32_t SDCapacity;
BYTE buffer[512];       // file copy buffer
UINT br, bw;            // File R/W count

int main()
{
	Systick_Init();
	NVIC_Configuration();
	LED_Init();
	
	while(disk_initialize(0)!=0)
	{
		LED0 = !LED0;
	}
	f_mount(0,&SD_fs);                           
	SDCapacity = SDCardInfo.CardCapacity>>20;
		                                           
	SD_res = f_open(&SD_file, "0:/Demo.TXT", FA_READ); 
	SD_res = f_read(&SD_file, buffer, sizeof(buffer), &br);
	if(SD_res == FR_OK)
	{
		LED0 = 1;
	}
	f_close(&SD_file); 
	
	while(1)
	{
		
	}
}
