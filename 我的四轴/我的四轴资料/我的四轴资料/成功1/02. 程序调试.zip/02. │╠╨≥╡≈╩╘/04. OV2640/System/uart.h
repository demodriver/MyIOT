#ifndef __UART_H
#define __UART_H

#include "stm32f4xx.h"

void UART_Init(void);
void UART_Send1Byte(u8 byte);
void UART_SendNByte(u8 *data, u16 num);
void UART_SendString(u8 *str);

#endif

