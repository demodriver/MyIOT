#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f4xx.h"
#include "sys.h"

void Motor_Init(void);
void TIM3_PWM_OUTPUT(u16 DR1, u16 DR2, u16 DR3, u16 DR4);

#endif
