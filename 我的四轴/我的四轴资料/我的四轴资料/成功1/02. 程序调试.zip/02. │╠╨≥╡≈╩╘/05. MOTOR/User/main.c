
#include "stm32f4xx.h"
#include "delay.h"
#include "stdio.h"
#include "led.h"
#include "motor.h"

int main()
{
	Systick_Init();
	NVIC_Configuration();
	LED_Init();
	Motor_Init();
	
	while(1)
	{
		TIM3_PWM_OUTPUT(0, 0, 0, 0);
		delay_ms(1000);
		TIM3_PWM_OUTPUT(200, 200, 200, 200);
		delay_ms(1000);
		TIM3_PWM_OUTPUT(400, 400, 400, 400);
		delay_ms(1000);
		TIM3_PWM_OUTPUT(800, 800, 800, 800);
		delay_ms(1000);
		TIM3_PWM_OUTPUT(1000, 1000, 1000, 1000);
		delay_ms(1000);
	}
}
