#include "esp8266.h"
#include "config.h"
#include "delay.h"
#include "led.h"
#include "string.h"
#include "uart.h"

#define 	WIFI_SendString			USART2_SendString
#define 	WIFI_SendNByte			USART2_SendNByte
WIFI_RxType WIFI_Rx;
WIFI_PropertyType WIFI_Property;

static u8 WIFI_StrCmp(u8 *str, u16 *site)
{
	u16 i;
	for(i=0; i<WIFI_Rx.RxNum; i++)
	{
		if(memcmp(&WIFI_Rx.RxbufPro[i], str, sizeof((char*)str)) == 0)
		{
			*site = i;
			return 0;
		}
	}
	return 1;
}

u8 WIFI_GPIO_Init(void)
{
	u16 i;
	
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOE, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_SetBits(GPIOB,	GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);
	GPIO_SetBits(GPIOE, GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10);
	
	delay_ms(1000);
	
	if(WIFI_ReceiveFinish())
	{
		if(WIFI_StrCmp((u8 *)"ready", &i))
		{
			return 1;
		}
	}
	return 0;
}

u8 WIFI_Reset(void)
{
	u16 i;
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString((u8 *)"AT+RST\r\n");
	delay_ms(1000);
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_WifiModeSelect(u8 mode)
{
	u16 i;
	u8 s[] = "AT+CWMODE=1\r\n";
	s[10] = mode+'0';
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString(s);
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_AccessNetwork(u8 *name, u8 *password)
{
	u8 s[60];
	u16 i;
	strcpy((char *)s, "AT+CWJAP=\"");
	strcat((char *)s, (char *)name);
	strcat((char *)s, "\",\"");
	strcat((char *)s, (char *)password);
	strcat((char *)s, "\"\r\n");
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString(s);
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_AccessNetworkCheck(void)
{
	return 0;
}

u8 WIFI_IPAddressCheck(void)
{
	u16 i;
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString((u8 *)"AT+CIFSR\r\n");
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_MultiConnectionMode(u8 mode)
{
	u16 i;
	u8 s[] = "AT+CIPMUX=1\r\n";
	s[10] = mode+'0';
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString(s);
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_ConnectionEstablishment(u8 id, u8 *type, u8 *addr, u8 *port)
{
	u8 s[60];
	u16 i;
	WIFI_Property.ID = id;
	strcpy((char *)s, "AT+CIPSTART=0,\"");
	s[12] = id + '0';
	strcat((char *)s, (char *)type);
	strcat((char *)s, "\",\"");
	strcat((char *)s, (char *)addr);
	strcat((char *)s, "\",");
	strcat((char *)s, (char *)port);
	strcat((char *)s, "\r\n");
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString(s);
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_SendDada(u8 *data, u8 num)
{
	u8 s[60];
	u16 i;
	strcpy((char *)s, "AT+CIPSEND=0,00\r\n");
	s[11] = WIFI_Property.ID + '0';
	s[13] = num/10%10 + '0';
	s[14] = num/1%10 + '0';
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString(s);
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	delay_ms(10);
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendNByte(data, num);
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_VersionCheck(void)
{
	u16 i;
	memset(&WIFI_Rx.RxbufNow[i], 0x00, WIFI_BUFFER_SIZE);
	memset(&WIFI_Rx.RxbufPro[i], 0x00, WIFI_BUFFER_SIZE);
	WIFI_SendString((u8 *)"AT+GMR\r\n");
	while(!WIFI_ReceiveFinish());
	if(WIFI_StrCmp((u8 *)"OK", &i))
	{
		return 1;
	}
	return 0;
}

u8 WIFI_Init(void)
{
	u8 cot = 0;
	if(WIFI_GPIO_Init()) cot++;
	delay_ms(100);
	if(WIFI_Reset()) cot++;
	delay_ms(100);
	if(WIFI_WifiModeSelect(1)) cot++;
	delay_ms(100);
	if(WIFI_Reset()) cot++;
	delay_ms(100);
	if(WIFI_AccessNetwork("zzzz", "zzzz71b402")) cot++;
	delay_ms(100);
	if(WIFI_IPAddressCheck())	cot++;
	delay_ms(100);
	if(WIFI_MultiConnectionMode(1)) cot++;
	delay_ms(100);
	if(WIFI_ConnectionEstablishment(4, "TCP", "192.168.1.105", "9999")) cot++;
	delay_ms(100);
	if(WIFI_SendDada("0123456789abcd\r\n", 16)) cot++;
	return cot;
}

u8 WIFI_ReceiveFinish(void)
{
	if(WIFI_Rx.RxFlag == 1 && WIFI_Rx.RxTimeOut == 0)
	{
		WIFI_Rx.RxFlag = 0;
		WIFI_Rx.RxNum = WIFI_Rx.Rxcot;
		WIFI_Rx.Rxcot = 0;
		memcpy(WIFI_Rx.RxbufPro, WIFI_Rx.RxbufNow, WIFI_Rx.RxNum);
 		return 1;
	}
	return 0;
}

void WIFI_TimeISR(void)
{
	if(WIFI_Rx.RxTimeOut > 0)
	{
		WIFI_Rx.RxTimeOut--;
	}
}

void WIFI_ReceiveProcess(u8 c)
{
	WIFI_Rx.RxbufNow[WIFI_Rx.Rxcot++] = c;
	WIFI_Rx.RxTimeOut = WIFI_UART_TIMEOUT/TICKS_PERIOD;
	WIFI_Rx.RxFlag = 1;
}
