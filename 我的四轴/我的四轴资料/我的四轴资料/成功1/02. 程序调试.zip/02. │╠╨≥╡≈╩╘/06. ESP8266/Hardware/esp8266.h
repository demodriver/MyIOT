#ifndef __WIFI8266_H
#define __WIFI8266_H

#include "stm32f4xx.h"

#define WIFI_BUFFER_SIZE 512

typedef struct{
	u8 RxbufNow[WIFI_BUFFER_SIZE];
	u8 RxbufPro[WIFI_BUFFER_SIZE];
	u8 RxFlag;
	u16 Rxcot;
	u16 RxNum;
	u16 RxTimeOut;
} WIFI_RxType;

typedef struct{
	u8 ConnectionStatus;
	u8 IPAddress[20];
	u8 ID;
} WIFI_PropertyType;



u8 WIFI_Init(void);
u8 WIFI_GPIO_Init(void);
u8 WIFI_Reset(void);
u8 WIFI_WifiModeSelect(u8 mode);
u8 WIFI_AccessNetwork(u8 *name, u8 *password);
u8 WIFI_AccessNetworkCheck(void);
u8 WIFI_MultiConnectionMode(u8 mode);
u8 WIFI_VersionCheck(void);
u8 WIFI_IPAddressCheck(void);
u8 WIFI_ConnectionEstablishment(u8 id, u8 *type, u8 *addr, u8 *port);
u8 WIFI_SendDada(u8 *data, u8 num);

void WIFI_TimeISR(void);
void WIFI_ReceiveProcess(u8 c);
u8 WIFI_ReceiveFinish(void);

#endif
