#ifndef __DELAY_H
#define __DELAY_H 	

#include "stm32f4xx.h"

void delay_ms(uint32_t n);
void delay_us(uint32_t n);

uint32_t time_nowMs(void);
uint64_t time_nowUs(void);

void Systick_Init(void);
void SysTick_ISR(void);

#endif
